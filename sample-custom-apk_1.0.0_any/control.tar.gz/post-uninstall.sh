#!/bin/sh

# post uninstall script here

exit 0
