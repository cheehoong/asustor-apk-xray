#!/bin/sh

# pre uninstall script here

exit 0
